export const environment = {
  production: true,
  firebaseAPIKey: 'AIzaSyCcb29Q2A24wiW1cTHktXlRyWHSFdUfcC0'
};
